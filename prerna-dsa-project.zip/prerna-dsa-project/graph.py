import tkinter as tk
from tkinter import filedialog, messagebox

# Initialize adjacency matrix and existence array
adjacency_matrix = [[-1 for _ in range(26)] for _ in range(26)]
is_exists = [0] * 26
is_file_read = False

# Function to read file and update adjacency matrix
def read_input_file():
    global is_file_read, adjacency_matrix, is_exists
    
    # Reset adjacency matrix and is_exists array
    is_exists = [0] * 26
    adjacency_matrix = [[-1] * 26 for _ in range(26)]
    
    # Open file dialog
    file_path = filedialog.askopenfilename(filetypes=[("Text Files", "*.txt")])
    
    if not file_path:
        return
    
    try:
        with open(file_path, 'r') as file:
            for line in file:
                parts = line.strip().split(',')
                
                if len(parts) < 3:
                    print(f"Skipping invalid line: {line.strip()}")
                    continue
                
                first, second = parts[0].strip().upper(), parts[1].strip().upper()
                
                try:
                    intensity = int(parts[2].strip())
                except ValueError:
                    print(f"Skipping invalid intensity value: {parts[2]}")
                    continue

                # Convert characters to indices
                first_index = ord(first) - ord('A')
                second_index = ord(second) - ord('A')

                if 0 <= first_index < 26 and 0 <= second_index < 26:
                    is_exists[first_index] = is_exists[second_index] = 1
                    adjacency_matrix[first_index][second_index] = intensity
                    adjacency_matrix[second_index][first_index] = intensity

        is_file_read = True
        messagebox.showinfo("Success", f"File '{file_path}' successfully read!")

    except FileNotFoundError:
        messagebox.showerror("Error", f"File not found.")
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

# Function to display adjacency matrix
def show_adjacency_matrix():
    if not is_file_read:
        messagebox.showwarning("Warning", "Please read a file first.")
        return

    # Clear previous matrix display
    for widget in matrix_frame.winfo_children():
        widget.destroy()
    
    tk.Label(matrix_frame, text="Adjacency Matrix", bg="black", fg="white", font=("Helvetica", 12, "bold")).grid(row=0, column=0, columnspan=26)
    
    # Display header row
    header = [chr(i + ord('A')) for i in range(26) if is_exists[i]]
    for col, letter in enumerate(header, start=1):
        tk.Label(matrix_frame, text=letter, borderwidth=1, relief="solid", width=4, bg="black", fg="white").grid(row=1, column=col)
    
    row_idx = 2
    for i in range(26):
        if is_exists[i]:
            tk.Label(matrix_frame, text=chr(i + ord('A')), borderwidth=1, relief="solid", width=4, bg="black", fg="white").grid(row=row_idx, column=0)
            col_idx = 1
            for j in range(26):
                if is_exists[j]:
                    value = adjacency_matrix[i][j] if adjacency_matrix[i][j] != -1 else "-"
                    tk.Label(matrix_frame, text=value, borderwidth=1, relief="solid", width=4, bg="black", fg="white").grid(row=row_idx, column=col_idx)
                    col_idx += 1
            row_idx += 1

# Create main window with black background
root = tk.Tk()
root.title("Graph Adjacency Matrix")
root.configure(bg="black")

# Center buttons frame and add background color to buttons
btn_frame = tk.Frame(root, bg="black")
btn_frame.pack(pady=10)

btn_style = {"bg": "#1e90ff", "fg": "white", "font": ("Helvetica", 10, "bold"), "width": 20, "height": 2}

tk.Button(btn_frame, text="Read File", command=read_input_file, **btn_style).grid(row=0, column=0, padx=10, pady=5)
tk.Button(btn_frame, text="Show Adjacency Matrix", command=show_adjacency_matrix, **btn_style).grid(row=0, column=1, padx=10, pady=5)
tk.Button(btn_frame, text="Exit", command=root.quit, **btn_style).grid(row=0, column=2, padx=10, pady=5)

# Frame for adjacency matrix display
matrix_frame = tk.Frame(root, bg="black")
matrix_frame.pack(pady=10)

# Run main event loop
root.mainloop()
